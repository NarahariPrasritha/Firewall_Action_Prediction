import pandas as pd
from flask import Flask, render_template, request, redirect, url_for
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import numpy as np

# Initialize Flask app
app = Flask(__name__)

# Load the resampled dataset
resampled_data = pd.read_csv('resampled_data.csv')  # Replace with actual file path

# Separate features and target
X_resampled = resampled_data.drop('Action_encoded', axis=1)  # Drop target column
y_resampled = resampled_data['Action_encoded']  # Target column

# Use the selected features for model training
X_selected = X_resampled[['NAT Source Port', 'Destination Port', 'Source Port', 
                          'NAT Destination Port', 'Bytes Sent', 'Elapsed Time (sec)', 'Bytes']]  # Selected features
y_selected = y_resampled  # Target variable (Action_encoded)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_selected, y_selected, test_size=0.3, random_state=42, stratify=y_selected)

# Initialize the Random Forest classifier with 'balanced' class weights to handle class imbalance
model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')

# Train the Random Forest model on the training data
model.fit(X_train, y_train)

# Make predictions on the test data
y_pred = model.predict(X_test)

# Evaluate the performance of the model
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='weighted')
recall = recall_score(y_test, y_pred, average='weighted')
f1 = f1_score(y_test, y_pred, average='weighted')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user inputs from the form
        nat_source_port = int(request.form['nat_source_port'])
        destination_port = int(request.form['destination_port'])
        source_port = int(request.form['source_port'])
        nat_destination_port = int(request.form['nat_destination_port'])
        bytes_sent = float(request.form['bytes_sent'])
        elapsed_time = float(request.form['elapsed_time_sec'])
        bytes_ = float(request.form['bytes'])

        # Create the feature vector
        input_features = np.array([[nat_source_port, destination_port, source_port, 
                                    nat_destination_port, bytes_sent, elapsed_time, bytes_]])

        # Predict the action using the trained model
        prediction = model.predict(input_features)

        # Map the encoded prediction back to the actual action labels
        action_map = {0: 'allow', 1: 'deny', 2: 'drop', 3: 'reset-both'}
        predicted_action = action_map[prediction[0]]

        return render_template('index.html', prediction_text=f'Firewall will {predicted_action} the network')

    except Exception as e:
        return render_template('index.html', prediction_text=f'Error: {e}')

if __name__ == "__main__":
    app.run(debug=True)
